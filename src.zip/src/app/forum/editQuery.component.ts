import { Component } from '@angular/core';

@Component({
    selector: 'app-edit-query',
    template: `<h3 mat-dialog-content>Edit functionality is in progress!!!</h3>`
})
export class EditQueryComponent {}