
import { Component, OnInit } from '@angular/core';
import { QuestionService } from '../question.service';
import { Query } from '../question.model';
import { MatDialog } from '@angular/material';
import { EditQueryComponent } from './../editQuery.component';

@Component({
  selector: 'app-my-queries',
  templateUrl: './my-queries.component.html',
  styleUrls: ['./my-queries.component.css']
})
export class MyQueriesComponent implements OnInit {
  myQueries: Query[] = [];
  query: Query;

  constructor(private queryService: QuestionService,  private dialog: MatDialog) { }

  ngOnInit() {
    this.myQueries = this.queryService.getQueries();
  }

onDelete(id: number) {
  this.myQueries = this.queryService.onDelete(id);
  }

  onEdit(id: number) {
    this.dialog.open(EditQueryComponent);
  }
}
