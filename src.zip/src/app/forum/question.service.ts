import { Injectable } from '@angular/core';
import { Query } from './question.model';

@Injectable({
  providedIn: 'root'
})
export class QuestionService {
questions: Query[] = [];

availaibleQuestions: Query[]  = [
  {id: 'Tech', question: 'How to request for Domain access in BOFA?', description: 'Please explain briefly how to get the domain access for BOFA public domain', state: 'completed', date: 1428496544765},
  {id: 'Tech1', question: 'How to raise an ARM request?', description: 'Please explain briefly how to raise an ARM request', state: 'completed', date: 1428496548787},
  {id: 'Tech2', question: 'How to find the profile in FlagScapePortal?', description: 'Please explain briefly how to get the own profile information in Flagscape Portal', state: 'completed', date: 1428496544000},
  {id: 'Tech3', question: 'How to raise request for IM?', description: 'Please explain briefly how to raise a Skype access request', state: 'completed', date: 1478656544765},
  {id: 'Tech4', question: 'How to request an Mail box?', description: 'Please explain briefly how to raise a mailbox request', state: 'completed', date: 1098766544765},
  {id: 'Tech5', question: 'How to call to support?', description: 'Please tell us how to call to support', state: 'completed', date: 1428496544765},
  {id: 'Tech6', question: 'How to find the another employee NBK ID with the given name?', description: 'Please explain how to get the NBK ID of the employee if we know the name', state: 'completed', date: 1428496544123},
  {id: 'Tech7', question: 'How to get the information about the windows trasfer?', description: 'i want to move my domain from corp to asia .. what is the process ? can anyone tell me', state: 'completed', date: 1428496544111},
  {id: 'Tech8', question: 'How to get the authentication number to call oniste ?', description: 'Please explain how to get the authentication number', state: 'completed', date: 142849654222},
  {id: 'Tech9', question: 'How to raise  request for VOIP?', description: 'Please explain briefly how to request for VOIP', state: 'completed', date: 142849654000},
];
  constructor() {
  }

  SaveQueries(question: string, description: string) {
    const que: Query = {
      id: '',
      question: question,
      description: description
    };
      this.questions.push(que);
  }

  getQueries() {
    return this.questions;
  }

  getAvailQueries() {
    if (this.questions.length > 0) {
      this.questions.forEach(element => {
        this.availaibleQuestions.push(element);
      });
    }
    return this.availaibleQuestions;
  }

  onDelete(id: number) {
    const query = this.questions.splice(id, 1);
    return this.questions;
  }

}
