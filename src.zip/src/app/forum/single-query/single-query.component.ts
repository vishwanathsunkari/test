import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-single-query',
  templateUrl: './single-query.component.html',
  styleUrls: ['./single-query.component.css']
})
export class SingleQueryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
